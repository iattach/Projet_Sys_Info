void main() {

  int a = 20;
  int * b = &a;
  printf(a);
  int c = *b;
  printf(c);

}
