void main() {

  int a = 10;
  if (a>0) {
    a = a - 1;
    printf(a);
  }

  int b = 50;
  if (b > 80) {
    printf(b);
  } else {
    b = 20 + a;
    printf(b);
  }

}
