void main()
{
  int a = 10;
  while (a > 0)
  {
    a = a - 1;
    printf(a);
  }
  printf(a);
}
