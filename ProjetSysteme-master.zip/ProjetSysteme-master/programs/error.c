void main() {

  int a = 10;
  int b;
  a = b*20;
  printf(a);

}
