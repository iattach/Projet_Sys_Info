int main() {
  int a = 10;
  int b = 20, c=50;
  int d = (b+c)/a;
  printf(d);
  return 0;
}
