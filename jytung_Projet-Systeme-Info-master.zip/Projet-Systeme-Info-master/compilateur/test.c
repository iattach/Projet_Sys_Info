int main()
{
   int i, j,k ,r;
   const int cs=50;
   i=3 ;
   j=4 ;
   k=8 ;
   printf (i) ;
  
   if (i==j){
       printf(i);
       printf(i);
   }
   else{
       i=i+1;
   }
   k=5;
 
   while(i==6){
       i=i+1;
   }
}
