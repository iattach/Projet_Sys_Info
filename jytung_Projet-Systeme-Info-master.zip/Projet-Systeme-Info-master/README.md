# Projet-Systeme-Info
Pour la partie compilateur: 

## Compilation : <br/>
`make clean` <br/>
`make all` <br/>

## Test:
`make test` <br/>
Le code assembleur generé par notre parseur est stocké dans asm.txt<br/>
Le code assembleur en hexadécimale generé par notre parseur est stocké dans asm_bin.asm <br/>
NB. Ces derniers ne peut pas être écrit dans une seule execution donc il faut commenter soit la fonction print_all() ou la fonction print_binaire() pour que l'écriture dans le fichier se fait correctement. 

